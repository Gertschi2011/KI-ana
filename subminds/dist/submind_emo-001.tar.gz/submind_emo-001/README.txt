Submind Paket
ID: emo-001
Installation: ./install_submind.sh [Zielpfad]
Start: <Zielpfad>/.venv/bin/python runtime_listener.py
